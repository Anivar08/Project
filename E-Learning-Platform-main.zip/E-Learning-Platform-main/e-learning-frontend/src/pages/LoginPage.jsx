import Login from '../components/Login';

const LoginPage = () => {
  return (
    <div className="page">
      <Login />
    </div>
  );
};

export default LoginPage;