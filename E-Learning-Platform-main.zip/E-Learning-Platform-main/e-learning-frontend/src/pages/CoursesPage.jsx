import CourseList from '../components/CourseList';

const CoursesPage = () => {
  return <CourseList />;
};

export default CoursesPage;