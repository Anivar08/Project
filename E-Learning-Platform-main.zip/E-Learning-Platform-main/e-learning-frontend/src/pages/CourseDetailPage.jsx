import CourseDetail from '../components/CourseDetail';

const CourseDetailPage = () => {
  return (
    <div className="page">
      <CourseDetail />
    </div>
  );
};

export default CourseDetailPage;